/*
 * SPDX-License-Identifier: BSD-2-Clause
 * 
 * Copyright (c) 2022 Vincent DEFERT. All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 * 
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 
 * 2. Redistributions in binary form must reproduce the above copyright 
 * notice, this list of conditions and the following disclaimer in the 
 * documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, 
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER 
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT 
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN 
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 * POSSIBILITY OF SUCH DAMAGE.
 */
#include "project-defs.h"
#include <i2c-hal.h>
#include <gpio-hal.h>

/**
 * @file i2c-hal.c
 * 
 * I2C abstraction implementation.
 */

#define CFG_PIN_SWITCH 0
#define CFG_SCL_PIN 1
#define CFG_SDA_PIN 2
#define CFG_ROW_SIZE 3

/*
 * I2C pin configurations (STC8 only)
 * 
 *  Value | SCL  | SDA  | Comment
 * -------+------+------+---------------
 *    0   | P3.2 | P3.3 | MCU_PINS == 8
 *    1   | P5.4 | P5.5 | MCU_PINS == 8
 * -------+------+------+---------------
 *    0   | P1.5 | P1.4 | MCU_PINS >= 20
 *    1   | P2.5 | P2.4 | MCU_PINS >= 28
 *    2   | P7.7 | P7.6 | MCU_PINS == 64
 *    3   | P3.2 | P3.3 | 
 */

static const uint8_t _pinConfigurations[][CFG_ROW_SIZE] = {
#if MCU_PINS == 8
	{ 0, 0x32, 0x33 },
	{ 1, 0x54, 0x55 },
#else
	#if MCU_PINS >= 20
		{ 0, 0x15, 0x14 },
	#endif // MCU_PINS >= 28
	
	#if MCU_PINS >= 28
		{ 1, 0x25, 0x24 },
	#endif // MCU_PINS >= 28
	
	#if MCU_PINS == 64
		{ 2, 0x77, 0x76 },
	#endif // MCU_PINS >= 28
	{ 3, 0x32, 0x33 },
#endif // MCU_PINS == 8
};

// On all STC8G, STC8H and the STC8A8K64D4, GPIO ports are configured
// in high-impedance mode by default, so configuring the output pins
// mode is *REQUIRED*.
static void _i2cConfigurePins(uint8_t pinSwitch) {
	for (uint8_t i = 0; i < (sizeof(_pinConfigurations) / CFG_ROW_SIZE); i++) {
		if (_pinConfigurations[i][CFG_PIN_SWITCH] == pinSwitch) {
			P_SW2 = (P_SW2 & ~M_I2C_S) | ((pinSwitch << P_I2C_S) & M_I2C_S);
			GpioConfig pinConfig = GPIO_PIN_CONFIG(GPIO_PORT3, GPIO_PIN0, GPIO_OPEN_DRAIN_MODE);
			uint8_t pinDefinition;
			
			pinDefinition = _pinConfigurations[i][CFG_SDA_PIN];
			pinConfig.port = (GpioPort) (pinDefinition >> 4);
			pinConfig.pin = (GpioPin) (pinDefinition & 0x0f);
			gpioConfigure(&pinConfig);
			
			pinDefinition = _pinConfigurations[i][CFG_SCL_PIN];
			pinConfig.port = (GpioPort) (pinDefinition >> 4);
			pinConfig.pin = (GpioPin) (pinDefinition & 0x0f);
#ifdef I2C_IS_SLAVE
			pinConfig.portMode = GPIO_HIGH_IMPEDANCE_MODE;
#endif // I2C_IS_SLAVE
			gpioConfigure(&pinConfig);
			break;
		}
	}
}

#ifdef I2C_IS_SLAVE
	// == SLAVE mode ===================================================
	
	static volatile I2C_SEGMENT bool _i2cStartReceived = false;
	
	void i2cInitialiseSlave(uint8_t pinSwitch, uint8_t slaveIdX2) {
		_i2cConfigurePins(pinSwitch);
		_i2cStartReceived = false;
		// Set slave address (or "promiscuous" mode, i.e. bit 0 = 1)
		I2CSLADR = slaveIdX2;
		// Clear interrupt flags and SLACKO
		I2CSLST = 0;
		// Enable interrupts
		I2CSLCR = M_STOIE | M_I2C_TXIE | M_I2C_RXIE | M_STAIE;
		// Enable I2C in SLAVE mode
		I2CCFG = M_ENI2C;
	}
	
	void i2cSendData(uint8_t byte) {
		I2CTXD = byte;
	}
	
	void i2cSendAck(I2C_AckNak value) {
		if (value) {
			I2CSLST |= M_SLACKO;
		} else {
			I2CSLST &= ~M_SLACKO;
		}
	}

	INTERRUPT(i2c_isr, I2C_INTERRUPT) {
		uint8_t p_sw2 = P_SW2;
		uint8_t flags = I2CSLST;
		
		if (flags & M_STOIF) {
			I2CSLST &= ~M_STOIF;
			P_SW2 = p_sw2;
			_i2cStartReceived = false;
			i2cOnStop();
		} else if (flags & M_I2C_TXIF) {
			I2CSLST &= ~M_I2C_TXIF;
			I2C_AckNak ack = (I2C_AckNak) ((I2CSLST & M_SLACKI) >> P_SLACKI);
			P_SW2 = p_sw2;
			i2cOnDataSent(ack);
		} else if (flags & M_I2C_RXIF) {
			I2CSLST &= ~M_I2C_RXIF;
			uint8_t byte = I2CRXD;
			P_SW2 = p_sw2;
			
			if (_i2cStartReceived) {
				_i2cStartReceived = false;
				i2cOnCommandReceived(byte >> 1, (I2C_Command) (byte & 1));
			} else {
				i2cOnDataReceived(byte);
			}
		} else if (flags & M_STAIF) {
			I2CSLST &= ~M_STAIF;
			P_SW2 = p_sw2;
			_i2cStartReceived = true;
		}
	}
#else
	// == MASTER mode ==================================================
	enum  I2C_Operations {
		I2C_standby = 0,
		I2C_start = 1,
		I2C_sendData = 2,
		I2C_receiveAck = 3,
		I2C_receiveData = 4,
		// Sends the value of MSACKO (0 = ACK, 1 = NAK)
		I2C_sendAck = 5,
		I2C_stop = 6,
		I2C_start_sendData_receiveAck = 9,
		I2C_sendData_receiveAck = 10,
		// Always sends an ACK, does not use MSACKO
		I2C_receiveData_sendAck0 = 11,
		// Always sends a NAK, does not use MSACKO
		I2C_receiveData_sendAck1 = 12,
	};

	void i2cInitialiseMaster(uint8_t pinSwitch, uint32_t i2cFreq) {
		_i2cConfigurePins(pinSwitch);
		
		uint8_t msSpeed = MCU_FREQ / i2cFreq / 4 - 2;
		
		if (msSpeed > 63) {
			msSpeed = 63;
		}
		
		// Initialise command register
		I2CMSCR = I2C_standby;
		// Clear flags
		I2CMSST = 0;
		// Enable I2C in MASTER mode
		I2CCFG = M_ENI2C | M_MSSL | msSpeed;
	}
	
	static void _waitForCompletion() {
		while (!(I2CMSST & M_MSIF));
		
		I2CMSST &= ~M_MSIF;
	}

	void i2cStart() {
		I2CMSCR = I2C_start;
		_waitForCompletion();
	}
	
	void i2cStop() {
		I2CMSCR = I2C_stop;
		_waitForCompletion();
	}
	
	void i2cSendAck(I2C_AckNak value) {
		if (value) {
			I2CMSST |= M_MSACKO;
		} else {
			I2CMSST &= ~M_MSACKO;
		}
		
		I2CMSCR = I2C_sendAck;
		_waitForCompletion();
	}
	
	void i2cSendData(uint8_t byte) {
		I2CTXD = byte;
		I2CMSCR = I2C_sendData;
		_waitForCompletion();
	}
	
	I2C_AckNak i2cReceiveAck() {
		I2CMSCR = I2C_receiveAck;
		_waitForCompletion();
		I2C_AckNak result = (I2C_AckNak) ((I2CMSST & M_MSACKI) >> P_MSACKI);
		
		return result;
	}
	
	uint8_t i2cReceiveData() {
		I2CMSCR = I2C_receiveData;
		_waitForCompletion();
		uint8_t result = I2CRXD;
		
		return result;
	}
	
	I2C_AckNak i2cStartCommand(uint8_t slaveAddress, I2C_Command command) {
		I2CTXD = (slaveAddress << 1) | command;
		I2CMSCR = I2C_start_sendData_receiveAck;
		_waitForCompletion();
		I2C_AckNak result = (I2C_AckNak) ((I2CMSST & M_MSACKI) >> P_MSACKI);
		
		return result;
	}
	
	I2C_AckNak i2cSendByte(uint8_t byte) {
		I2CTXD = byte;
		I2CMSCR = I2C_sendData_receiveAck;
		_waitForCompletion();
		I2C_AckNak result = (I2C_AckNak) ((I2CMSST & M_MSACKI) >> P_MSACKI);
		
		return result;
	}
	
	uint8_t i2cReadByteSendAck(I2C_AckNak value) {
		I2CMSCR = value ? I2C_receiveData_sendAck1 : I2C_receiveData_sendAck0;
		_waitForCompletion();
		uint8_t result = I2CRXD;
		
		return result;
	}
#endif // I2C_IS_SLAVE
