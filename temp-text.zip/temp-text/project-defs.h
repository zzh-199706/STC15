
#ifndef _PROJECT_DEFS_H
#define _PROJECT_DEFS_H

#ifdef __SDCC

	#include <STC/15W4KxxS4/stc15.h>

	
#endif // __SDCC

#define CONSOLE_UART   UART1
#define CONSOLE_SPEED  57600UL
#define CONSOLE_PIN_CONFIG 0




#endif // _PROJECT_DEFS_H
