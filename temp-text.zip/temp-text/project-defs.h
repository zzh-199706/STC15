
#ifndef _PROJECT_DEFS_H
#define _PROJECT_DEFS_H

#ifdef __SDCC
	//#include <STC/8A8KxxS4A12/LQFP48.h>
	//#include <STC/8A8KxxD4/LQFP48.h>
	//#include <STC/8G1Kxx/TSSOP20.h>
	//#include <STC/8G2KxxS4/LQFP48.h>
	//#include <STC/8H1Kxx/TSSOP20.h>
	//#include <STC/8H3KxxS2/TSSOP20.h>
	//#include <STC/8H3KxxS4/LQFP32.h>
	//#include <STC/8H8KxxU/PDIP40.h>
	#include <STC/15W4KxxS4/stc15.h>
	//#include <STC/12C5AxxS2/PDIP40.h>
	
#endif // __SDCC

#define CONSOLE_UART   UART1
#define CONSOLE_SPEED  57600UL
#define CONSOLE_PIN_CONFIG 0


// You should connect a known voltage source on DEMO_ADC_CHANNEL,
// but you may also leave it floating for the fun of it.

// On STC8, the value of channel 15 (internal voltage reference)
// will also be displayed.

// Reduce RAM footprint so we can use the medium memory model
// regardless of the MCU.
//#define HAL_UARTS 1

#endif // _PROJECT_DEFS_H
