#ifndef _STC15W4KXXS4_LQFP64_H
#define _STC15W4KXXS4_LQFP64_H

#define MCU_FAMILY 15                  // 属于 STC15 系列（正确，无需修改）
#define MCU_SERIES 'W'                 // 系列标识为 W（正确，无需修改）
#define MCU_PINS 64                    // 封装引脚数（IAP15W4K61S4 常见 LQFP44 封装）
#define MCU_MAX_FREQ_MHZ 35            // 最大工作频率 35MHz（数据手册明确值）
#define MCU_HAS_EAXSFR                 // 支持扩展 SFR（增强型特性，正确）
#define MCU_HAS_DUAL_DPTR              // 支持双数据指针（正确，无需修改）
#undef  MCU_HAS_COMPARATOR             // 不支持比较器（IAP15W4K 系列无此功能）
#define TIMERS_HAS_T3_T4               // 支持定时器 T3、T4（正确，含 T0-T4 共5个定时器）
#define PWM_GROUPS 2                   // PWM 分组数为 2（PWM1 和 PWM2 两组）
#define PWM_CHANNELS 8                 // 总 PWM 通道数 8（每组4通道，共 2×4=8）
#define NB_UARTS 4                     // 4 个 UART（正确，UART1-UART4）
#define ADC_CHANNELS 8                 // 8 个 ADC 通道（正确，P1.0-P1.7 复用）
#define NB_TIMERS 5                    // 5 个定时器（T0-T4，正确，无需修改）


#endif // _STC15W4KXXS4_LQFP64_H
