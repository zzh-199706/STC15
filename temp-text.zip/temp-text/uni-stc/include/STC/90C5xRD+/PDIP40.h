
/**
 * @file STC/90C5xRD/PDIP40.h
 * 
 * Register, bit and macro definitions for the STC90
 */

#ifndef _STC90C5xRD_PDIP40_H
#define _STC90C5xRD_PDIP40_H

#define MCU_FAMILY 90
#define MCU_SERIES 'C'
#define MCU_PINS 40
#define MCU_MAX_FREQ_MHZ 40

#define MCU_CYCLES 12

#define MCU_HAS_NO_P5
#define NB_TIMERS 3
#define MCU_HAS_DUAL_DPTR



__sbit  __at(0xA2)      DPS;

#endif // _STC90C5xRD_PDIP40_H
